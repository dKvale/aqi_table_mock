# Forecast table mock-ups
  
1. __Regional list__      https://dkvale.github.io/aqi_table_mock/index_regions.html  
2. __Navigation bar__     https://dkvale.github.io/aqi_table_mock/index_regions_nav.html  
3. __Collapsible regions__  https://dkvale.github.io/aqi_table_mock/index_regions_btns.html  
4. __Forecast maps__  https://dkvale.github.io/aqi_table_mock/index_aqi_maps.html  
